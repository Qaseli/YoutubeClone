﻿namespace YouTubeApiProject.Models
{
    public class YouTubeVideoModel
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public string ThumbnailUrl { get; set; }
        public string VideoId { get; set; }
        public string VideoUrl { get; set; }
        public DateTimeOffset? PublishedAt { get; set; }  // Upload Date
        public string ChannelTitle { get; set; }
        public string IsLive { get; set; }  // Changed to bool for better representation


        // Method to get the time difference in a human-readable format
        public string GetPublish()
        {
            if (!PublishedAt.HasValue)
                return "Unknown";

            var difference = DateTime.UtcNow - PublishedAt.Value.ToUniversalTime();
            var (time, text) = GetTimeAgo(difference);

            return $"{time} {text}";
        }

        private (int time, string text) GetTimeAgo(TimeSpan difference)
        {
            int time;
            string text;

            if (difference.TotalSeconds < 60)
            {
                time = (int)difference.TotalSeconds;
                text = time == 1 ? "second ago" : "seconds ago";
            }
            else if (difference.TotalMinutes < 60)
            {
                time = (int)difference.TotalMinutes;
                text = time == 1 ? "minute ago" : "minutes ago";
            }
            else if (difference.TotalHours < 24)
            {
                time = (int)difference.TotalHours;
                text = time == 1 ? "hour ago" : "hours ago";
            }
            else if (difference.TotalDays < 7)
            {
                time = (int)difference.TotalDays;
                text = time == 1 ? "day ago" : "days ago";
            }
            else if (difference.TotalDays < 30)
            {
                time = (int)(difference.TotalDays / 7); // Convert to weeks
                text = time == 1 ? "week ago" : "weeks ago";
            }
            else if (difference.TotalDays < 365)
            {
                time = (int)(difference.TotalDays / 30); // Convert to months
                text = time == 1 ? "month ago" : "months ago";
            }
            else
            {
                time = (int)(difference.TotalDays / 365); // Convert to years
                text = time == 1 ? "year ago" : "years ago";
            }

            return (time, text);
        }
    }
}
